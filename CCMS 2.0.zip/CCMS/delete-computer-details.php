<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
strlen($_SESSION['ccmsaid']==0);
  
$id=$_GET['id'];
$cmsaid=$_SESSION['ccmsaid'];

 $query=mysqli_query($con,"DELETE FROM tblcomputers  WHERE ID='".$id."'");

    if ($query) {
    $msg="Computer Detail has been deleted!";
     header( "Location: manage-computer.php");
  }
  else
    {
      $msg="Something Went Wrong. Please try again";
       header( "Location: manage-computer.php");
    }

  

?>