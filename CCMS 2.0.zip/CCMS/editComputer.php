<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['ccmsaid']==0)) {
  header('location:logout.php');
  } else{

      ?>
      <?php
if (isset($_GET['delete'])){
    $ID = $_GET['delete'];
    $link->query("DELETE FROM tblcomputers WHERE ID='$ID'") or die(mysqli_error($con));

    $_SESSION['message'] = "Record has been deleted!";
    $_SESSION['msg_type'] = "danger";

    header( "Location: manage-computer.php");
    }
    ?>